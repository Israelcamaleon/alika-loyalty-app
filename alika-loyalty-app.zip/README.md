# Alika Salon - App de Lealtad

App web modular para sistema de lealtad personalizada.