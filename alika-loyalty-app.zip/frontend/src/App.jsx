import React from 'react';
export default function App() {
  return <h1>Bienvenida a Alika Salon</h1>;
}